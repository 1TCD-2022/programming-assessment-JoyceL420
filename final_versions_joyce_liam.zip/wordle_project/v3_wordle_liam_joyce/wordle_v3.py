# Attempt at wordle oh god what am I doing

# import
import random

"""
Filename:Wordle
Author:Liam Joyce
Date:started 27/6/22
Description: Wordle but in python (based off wordle)
"""

# CONVERT .TXT TO STRING
# https://www.tutorialkart.com/python/python-read-file-as-string/
text_file = open("word_list_5.txt")

text = text_file.read()

text_file.close()

POTENTIAL_5_WORDS = text.split()

text_file = open("word_list_6.txt")

text = text_file.read()

text_file.close()

POTENTIAL_6_WORDS = text.split()

text = None


print("Welcome to Wordle in python!\n")
print("This game was made in PyScripter (there may be some indentation problems if you run it through idle)\n")
print("Y/yellow means correct letter, G/green means correct letter and position, N just means no, have fun ;)\n")

# variables
attempt = 0  # Self explanetory
win = False  # Tells the game whether to end the game loop or not
replay = "yes"


def six_or_five():
    five_or_six = "0"
    while five_or_six != "6" and five_or_six != "5":
        five_or_six = str(input("Would you like to play with 5 letter words or 6 letter words?\n")).strip().lower()
        if five_or_six == "6" or five_or_six == "six":
            print("6 Letter word it is!\n")
            five_or_six = "6"
            return five_or_six
        elif five_or_six == "5" or five_or_six == "five":
            print("5 letter word it is!\n")
            five_or_six = "5"
            return five_or_six
            pass
        else:
            print("That is NOT a valid input\n")
    return five_or_six


# Modules
def player_guess():
    guess = str(input("Please enter a 5 letter word:\n")).strip().upper()  # Prompts user to enter a word
    while len(guess) != 5 or not guess.isalpha():  # Making sure that a valid word has been entered.
        if not guess.isalpha():  # Tells the user what they did wrong
            guess = str(input("Please enter an actual 5 LETTER word:\n")).strip().upper()
        else:  # Tells the user what they did wrong
            guess = str(input("Please enter a  F I V E  letter word:\n")).strip().upper()
    print("You guessed the word \"{}\"".format(guess))
    return guess


def player_guess_6():
    guess = str(input("Please enter a 6 letter word:\n")).strip().upper()  # Prompts user to enter a word
    while len(guess) != 6 or not guess.isalpha():  # Making sure that a valid word has been entered.
        if not guess.isalpha():  # Tells the user what they did wrong
            guess = str(input("Please enter an actual 6 LETTER word:\n")).strip().upper()
        else:  # Tells the user what they did wrong
            guess = str(input("Please enter a  S I X  letter word:\n")).strip().upper()
    print("You guessed the word \"{}\"".format(guess))
    return guess


def compare(guess, attempt):
    # Word check (correct)
    if guess == word:
        if attempt == 1:
            print("Congratulations! It took you... {} attempt... how?".format(attempt))
            attempt = 6
            win = True
            return True
        else:
            print("Congratulations you did it! It took you {} attempts!".format(attempt))
            attempt = 6
            win = True
            return True
    status = []

    # Word check (compare)
    # Also for a bit of context, word.find() returns -1 if nothing was found

# Reset variables~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    position = -1
    position_c = -1
    instances = []
    correct = []
    status = []
# Get letter instances~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for letter in word:
        instances.append(letter)
# Mark correct positions~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for index in range(len(guess)):
        position_c += 1
        if word[index].find(guess[index]) != -1:
            correct.append(position_c)
            try:
                instances.remove(guess[index])
            except:
                pass
# Start of for loop~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for i in range(len(guess)):
        position += 1
    # Correct~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if word[i].find(guess[i]) != -1:
            status.append("G")
    # Correct letter~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        elif word.find(guess[i]) != -1:
            if guess[i] in instances and position not in correct:
                status.append("Y")
                try:
                    instances.remove(guess[i])
                except:
                    pass
# Correct letter but no new instances~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            else:
                status.append("N")

    # Wrong ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        else:
            status.append("N")
    # Spacing
    print(status)


# MAIN GAME
while replay == "yes" or replay == "y":
    five_or_six = six_or_five()
    if five_or_six == "5":
        word = random.choice(POTENTIAL_5_WORDS).upper().strip()
    elif five_or_six == "6":
        word = random.choice(POTENTIAL_6_WORDS).upper().strip()
    print(word)
    while attempt != 6 and not win:  # Makes sure you don't going over the attempt limit
        attempt += 1  # Counts attempts
        print("You are currently on attempt {}/6\n".format(attempt))
        if five_or_six == "5":
            guess = str(player_guess())
        elif five_or_six == "6":
            guess = str(player_guess_6())
        win = compare(guess, attempt)
    if not win:
        print("You lost! The word was {}".format(word))
    replay = str(input("Would you like to play again? (y, n)")).lower().strip()
    while replay != "y" and replay != "yes" and replay != "n" and replay != "no":
        replay = str(input("Would you like to play again? (y, n)")).lower().strip()
    attempt = 0
    win = False
print("Goodbye!")
# GAME END
