Probably the final version!

I would add colors to text to make things clearer for the user but I can't because that requires downloading colorama and some guy controls the downloads!
Anyways

The word lists are now stored in text files! And I found a lot of words

Things have been moved into modules and there is now a 6 word mode. Fun times :D


IF YOU DELETE THE TEXT FILES YOU WILL CAUSE uh oh ISSUES