Few changes from the original version 3

Changes made: 17/8/22
Added a win/loss counter
Allowed the user to set their attempts and upped the default attemps for the user from 6 to 8 on the 6 letter word
Added an update log in case I decide to make more changes.
