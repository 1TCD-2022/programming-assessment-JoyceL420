Hooray, the false positives issue has been fixed!

Not much has changed in regards to the code compared to the previous version apart from things neccesary to fix the bug

Many more words have been added as this is now a playable game but I will probably rewrite the list when I find a 5 letter word list

And proper naming convention with files "python_wordle" have not been used yet but I will for the third version