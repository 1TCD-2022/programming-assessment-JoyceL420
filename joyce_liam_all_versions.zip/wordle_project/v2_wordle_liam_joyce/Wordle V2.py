# Attempt at wordle oh god what am I doing

"""
Filename:Wordle
Author:Liam Joyce
Date:started 27/6/22
Description: Wordle but in python (based off wordle)
"""

#open text file in read mode
text_file = open("word_list.txt")

#read whole file to a string
data = text_file.read()

#close file
text_file.close()

print(data)


import random

POTENTIAL_5_WORDS = [] # add more words later
POTENTIAL_6_WORDS = ["PLEASE"]
attempt = 0 # Self explanetory
word = random.choice(POTENTIAL_5_WORDS).upper() #Chosen word from list
win = False # tells the game whether to end the game loop or not
guess = None #Player guess
status = [] # For coloring text
correct = [] # Used exclusively in yellow (correct letter wrong position)
# to put on a list all the correct positions and what to mark as wrong and what to mark as maybe)

print("Welcome to Wordle in python! This is version 2 and hopefully it works")
print("The list of words may have a few memes in them, you have been warned!")

def player_guess():  # PLACEHOLDER
   print("guess")


def compare():  # PLACEHOLDER
   print("compare")

while attempt != 6:  # Makes sure you don't going over the attempt limit
    attempt += 1  # Counts attempts
    print("You are currently on attempt {}/6\n".format(attempt))  # Attempt counter
    guess = str(input("Please enter a 5 letter word:\n")).strip().upper()  # Prompts user to enter a word

    while len(guess) != 5 or not guess.isalpha():  # Making sure that a valid word has been entered.
        if not guess.isalpha():# Tells the user what they did wrong
            guess = str(input("Please enter an actual 5 LETTER word:\n")).strip().upper()
        else:# Tells the user what they did wrong
            guess = str(input("Please enter a  F I V E  letter word:\n")).strip().upper()
    print("You guessed the word \"{}\"\n".format(guess))

    # Word check (correct)
    if guess == word:
        if attempt == 1:
            print("Congratulations! It took you... {} attempt... how?".format(attempt))
            attempt = 6
            win = True
            continue
        else:
            print("Congratulations you did it! It took you {} attempts!".format(attempt))
            attempt = 6
            win = True
            continue
    status = []

    # Word check (compare)
    # Also for a bit of context, word.find() returns -1 if nothing was found

# Reset variables~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    position = -1
    position_c = -1
    instances = []
    correct = []
# Get letter instances~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for letter in word:
        instances.append(letter)
# Mark correct positions~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for index in range (len(guess)):
        position_c += 1
        if word[index].find(guess[index]) != -1:
            correct.append(position_c)
            try:
                instances.remove(guess[index])
            except:
                pass
# Start of for loop~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for i in range (len(guess)):
        position += 1
    #Correct~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if word[i].find(guess[i]) != -1:
            print("pog/Correct letter and position (position {})".format(i + 1))
    #Correct letter~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        elif word.find(guess[i]) != -1:
            if guess[i] in instances and position not in correct:
                print("pog?/Correct letter wrong position (position {})".format(i +1))
                try:
                    instances.remove(guess[i])
                except:
                    pass
# Correct letter but no new instances~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            else:
                print("no/Incorrect letter (position {})".format(i + 1))

    #Wrong ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        else:
            print("no/Incorrect letter (position {})".format(i + 1))
    # Spacing
    print("")
#Loop end~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if not win:
    print("You lost! The word was {}".format(word))

