THE CODE DOES NOT WORK AS INTENDED

Alright cool

There is only ONE word right now and it is "funny" only there so I can get the false positives issue fixed.

Although that was not fixed in this version. If you want to see more elaboration on the false positives issue you can check my documentation