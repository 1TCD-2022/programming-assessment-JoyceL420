#Attempt at wordle oh god what am I doing

"""
Filename:Wordle
Author:Liam Joyce
Date:started 27/6/22
Description: Wordle but in python (based off wordle)
"""

import random

POTENTIAL_WORDS = ["FUNNY"] #Add actual words when you get this working, but for the time being just stick to something with different letters
attempt = 0
word = random.choice(POTENTIAL_WORDS)
win = False
guess = None
status = []
ignore = []
win = False

#print(word) #for TESTING purposes (remove in final version)

def player_guess(): #PLACEHOLDER
    print("guess")

def compare(): #PLACEHOLDERS
    print("compare")

#oh god the amount of nested loops in this bad boy
while attempt != 6: #Makes sure you dont going over the attempt limit
    attempt += 1 #Counts attempts
    print("You are currently on attempt {}/6\n".format(attempt)) #Attempt counter
    guess = str(input("Please enter a 5 letter word:\n")).strip().upper() #Prompts user to enter a word

    while len(guess) != 5 or guess.isalpha() == False:#Making sure that a valid word has been entered.
        if guess.isalpha() == False:
            guess = str(input("Please enter an actual 5 LETTER word:\n")).strip().upper()
        else:
            guess = str(input("Please enter a  F I V E  letter word:\n")).strip().upper()
    print("You guessed the word \"{}\"\n".format(guess))
    if guess == word:
        if attempt == 1:
            print("Congratulations! It took you... {} attempt... how?".format(attempt))
            attempt = 6
            win = True
            continue
        else:
            print("Congratulations you did it! It took you {} attempts!".format(attempt))
            attempt = 6
            win = True
            continue
    status = []
    ignore = []
    for i in range (len(guess)): #running only 5 times now so IT SHOULD WORK
        if word[i].find(guess[i]) != -1:
            print("pog/correct (position {})".format(i + 1))
            #add an ignore thingy and later a colour
        elif word.find(guess[i]) != -1:
            print("pog?/correct letter (position {})".format(i + 1))
            #add an ignore thingy and later a colour
        else:
            print("no/no")
    print("")

if win == False:
    print("You lost! The word was {}".format(word))






#Debugging purposes (will be removed in the final version
#print(status)
#print(ignore)